document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("query-form");
    const submitButton = document.getElementById("submit-button");

    form.addEventListener("submit", function (event) {
        event.preventDefault();

        
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const message = document.getElementById("message").value;

        alert("Thank you, " + name + ". Your query has been sent successfully!");

        form.reset();

        submitButton.disabled = true;
        setTimeout(() => {
            submitButton.disabled = false;
        }, 2000); 
    });
});
