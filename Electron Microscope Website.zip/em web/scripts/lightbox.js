console.log('Lightbox script loaded');

document.addEventListener('DOMContentLoaded', function () {
    const images = document.querySelectorAll('[data-lightbox="application"]');
    const lightboxContainer = document.getElementById('lightbox-container');
    const lightboxImage = document.getElementById('lightbox-image');

    if (!images.length || !lightboxContainer || !lightboxImage) {
        console.error('Lightbox elements not found');
        return;
    }

    images.forEach(image => {
        image.addEventListener('click', () => {
            lightboxContainer.style.display = 'flex';
            lightboxImage.src = image.src;
        });
    });

    lightboxContainer.addEventListener('click', (e) => {
        if (e.target === lightboxContainer) {
            lightboxContainer.style.display = 'none';
            lightboxImage.src = '';
        }
    });
});




